$(document).ready(function(){
    $( ".boton_desplegable1" ).click(function() {
      $( ".submenu1" ).slideToggle();
    });
    $( ".boton_desplegable2" ).click(function() {
      $( ".submenu2" ).slideToggle();
    });
    $( ".boton_desplegable3" ).click(function() {
      $( ".submenu3" ).slideToggle();
    });
    $( ".boton_desplegable4" ).click(function() {
      $( ".submenu4" ).slideToggle();
    });
});